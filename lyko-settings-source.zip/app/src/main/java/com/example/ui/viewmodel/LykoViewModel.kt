package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import android.app.Activity
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.LykoRepository
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthProvider
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class FeedTab {
    FOR_YOU,
    FOLLOWING,
    EXPLORE
}

enum class NavigationDestination {
    AUTH,
    FEED,
    EXPLORE,
    CREATE,
    REELS,
    PROFILE,
    MESSAGES,
    CHAT_DETAIL,
    STORY_VIEWER,
    LIVE_BROWSE,
    LIVE_ROOM,
    GO_LIVE,
    ADMIN_PANEL,
    NOTIFICATIONS,
    SETTINGS_PRIVACY,
    USER_PROFILE_DETAIL
}

class LykoViewModel(private val repository: LykoRepository = LykoRepository()) : ViewModel() {

    private var pendingPhoneProfileUid: String? = null

    val currentUser = repository.currentUser
    val isLoggedIn = repository.isLoggedIn
    val allUsers = repository.allUsers
    val stories = repository.stories
    val feedPosts = repository.feedPosts
    val reels = repository.reels
    val chatRooms = repository.chatRooms
    val liveStreams = repository.liveStreams
    val notifications = repository.notifications
    val reports = repository.reports
    val adCampaigns = repository.adCampaigns
    val blockedUserIds = repository.blockedUserIds
    val isPrivateAccount = repository.isPrivateAccount
    val allowDirectMessagesFromEveryone = repository.allowDirectMessagesFromEveryone
    val filterOffensiveComments = repository.filterOffensiveComments
    val highQualityMediaUploads = repository.highQualityMediaUploads

    fun setPrivateAccount(value: Boolean) = repository.setPrivateAccount(value)
    fun setDirectMessagesFromEveryone(value: Boolean) = repository.setDirectMessagesFromEveryone(value)
    fun setOffensiveCommentFilter(value: Boolean) = repository.setOffensiveCommentFilter(value)
    fun setHighQualityMediaUploads(value: Boolean) = repository.setHighQualityMediaUploads(value)

    // Navigation & UI State
    private val _currentScreen = MutableStateFlow(
        if (isLoggedIn.value) NavigationDestination.FEED else NavigationDestination.AUTH
    )
    val currentScreen = _currentScreen.asStateFlow()
    private val _holdAuthScreenForPhoneSetup = MutableStateFlow(false)

    init {
        viewModelScope.launch {
            combine(isLoggedIn, _holdAuthScreenForPhoneSetup) { loggedIn, holdAuth ->
                loggedIn && !holdAuth
            }.collect { canEnterFeed ->
                _currentScreen.value = if (canEnterFeed) NavigationDestination.FEED
                    else NavigationDestination.AUTH
            }
        }
    }

    private val _selectedFeedTab = MutableStateFlow(FeedTab.FOR_YOU)
    val selectedFeedTab = _selectedFeedTab.asStateFlow()

    // Active story viewer
    private val _activeStoryIndex = MutableStateFlow(0)
    val activeStoryIndex = _activeStoryIndex.asStateFlow()

    // Active Chat
    private val _selectedChatId = MutableStateFlow<String?>(null)
    val selectedChatId = _selectedChatId.asStateFlow()
    val activeChatThreadId = selectedChatId
    val chatThreads = chatRooms

    // Active Live Stream
    private val _selectedLiveStreamId = MutableStateFlow<String?>(null)
    val selectedLiveStreamId = _selectedLiveStreamId.asStateFlow()
    val activeLiveStreamId = selectedLiveStreamId

    // Active Inspect User Profile
    private val _inspectedUserId = MutableStateFlow<String?>(null)
    val inspectedUserId = _inspectedUserId.asStateFlow()
    val selectedUserProfileId = inspectedUserId

    // Explore Search
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _exploreCategory = MutableStateFlow("Trending")
    val exploreCategory = _exploreCategory.asStateFlow()

    // Comments Sheet State
    private val _activeCommentPostId = MutableStateFlow<String?>(null)
    val activeCommentPostId = _activeCommentPostId.asStateFlow()

    // Share Sheet State
    private val _activeSharePost = MutableStateFlow<Post?>(null)
    val activeSharePost = _activeSharePost.asStateFlow()

    // Report Dialog State
    private val _reportTarget = MutableStateFlow<Pair<String, String>?>(null) // (itemId, itemType)
    val reportTarget = _reportTarget.asStateFlow()

    // Floating heart triggers for Live Stream
    private val _heartBurstCount = MutableStateFlow(0)
    val heartBurstCount = _heartBurstCount.asStateFlow()

    // Voice recording simulation
    private val _isRecordingVoice = MutableStateFlow(false)
    val isRecordingVoice = _isRecordingVoice.asStateFlow()

    private val _voiceRecordingSeconds = MutableStateFlow(0)
    val voiceRecordingSeconds = _voiceRecordingSeconds.asStateFlow()

    // Toast / Snack message
    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage = _userMessage.asStateFlow()

    private val _phoneVerificationId = MutableStateFlow<String?>(null)
    val phoneVerificationId = _phoneVerificationId.asStateFlow()

    private var phoneCredential: PhoneAuthCredential? = null
    private val _phoneOtpReady = MutableStateFlow(false)
    val phoneOtpReady = _phoneOtpReady.asStateFlow()

    fun navigateTo(dest: NavigationDestination) {
        _currentScreen.value = dest
    }

    fun setFeedTab(tab: FeedTab) {
        _selectedFeedTab.value = tab
    }

    fun openStory(index: Int) {
        _activeStoryIndex.value = index
        _currentScreen.value = NavigationDestination.STORY_VIEWER
    }

    fun nextStory() {
        val count = stories.value.size
        if (_activeStoryIndex.value < count - 1) {
            _activeStoryIndex.value += 1
        } else {
            _currentScreen.value = NavigationDestination.FEED
        }
    }

    fun previousStory() {
        if (_activeStoryIndex.value > 0) {
            _activeStoryIndex.value -= 1
        }
    }

    fun openChat(chatId: String) {
        _selectedChatId.value = chatId
        _currentScreen.value = NavigationDestination.CHAT_DETAIL
    }

    fun openLiveStream(streamId: String) {
        _selectedLiveStreamId.value = streamId
        _currentScreen.value = NavigationDestination.LIVE_ROOM
    }

    fun openUserProfile(userId: String) {
        if (userId == currentUser.value.id) {
            _currentScreen.value = NavigationDestination.PROFILE
        } else {
            _inspectedUserId.value = userId
            _currentScreen.value = NavigationDestination.USER_PROFILE_DETAIL
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setExploreCategory(category: String) {
        _exploreCategory.value = category
    }

    fun openCommentsFor(postId: String) {
        _activeCommentPostId.value = postId
    }

    fun closeComments() {
        _activeCommentPostId.value = null
    }

    fun openShareSheet(post: Post) {
        _activeSharePost.value = post
    }

    fun closeShareSheet() {
        _activeSharePost.value = null
    }

    fun openReportDialog(itemId: String, itemType: String) {
        _reportTarget.value = Pair(itemId, itemType)
    }

    fun closeReportDialog() {
        _reportTarget.value = null
    }

    fun showMessage(msg: String) {
        _userMessage.value = msg
        viewModelScope.launch {
            delay(3000)
            if (_userMessage.value == msg) {
                _userMessage.value = null
            }
        }
    }


    fun sendPhoneOtp(activity: Activity, phoneNumber: String) {
        val phone = phoneNumber.trim()
        if (!Regex("^\\+[1-9]\\d{7,14}$").matches(phone)) {
            showMessage("Enter a valid phone number with country code, e.g. +91XXXXXXXXXX.")
            return
        }

        phoneCredential = null
        _phoneVerificationId.value = null
        _phoneOtpReady.value = false

        repository.sendPhoneVerification(
            activity,
            phone,
            object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                    phoneCredential = credential
                    _phoneOtpReady.value = true
                    showMessage("Phone verified. Enter your username and continue.")
                }

                override fun onVerificationFailed(exception: Exception) {
                    showMessage(exception.localizedMessage ?: "Phone verification failed.")
                }

                override fun onCodeSent(
                    verificationId: String,
                    token: PhoneAuthProvider.ForceResendingToken
                ) {
                    _phoneVerificationId.value = verificationId
                    _phoneOtpReady.value = true
                    showMessage("OTP sent. Check your SMS.")
                }

                override fun onCodeAutoRetrievalTimeOut(verificationId: String) {
                    _phoneVerificationId.value = verificationId
                }
            }
        )
    }

    fun verifyPhoneOtp(code: String, username: String) {
        val credential = phoneCredential ?: run {
            val verificationId = _phoneVerificationId.value
            if (verificationId.isNullOrBlank() || !code.trim().matches(Regex("\\d{6}"))) {
                showMessage("Enter the six-digit SMS code.")
                return
            }
            PhoneAuthProvider.getCredential(verificationId, code.trim())
        }

        _holdAuthScreenForPhoneSetup.value = true
        repository.signInWithPhoneCredential(credential).addOnCompleteListener { result ->
            if (!result.isSuccessful) {
                _holdAuthScreenForPhoneSetup.value = false
                showMessage(result.exception?.localizedMessage ?: "OTP verification failed.")
                return@addOnCompleteListener
            }

            val user = result.result.user
            if (user == null) {
                _holdAuthScreenForPhoneSetup.value = false
                showMessage("Phone sign-in succeeded, but account details were unavailable.")
                return@addOnCompleteListener
            }

            phoneCredential = null
            _phoneVerificationId.value = null
            _phoneOtpReady.value = false

            if (result.result.additionalUserInfo?.isNewUser == true) {
                pendingPhoneProfileUid = user.uid
                val cleanUsername = username.trim().removePrefix("@")
                if (cleanUsername.isBlank()) {
                    _phoneProfilePending.value = true
                    showMessage("New account: please enter a username to finish setup.")
                    return@addOnCompleteListener
                }
                saveNewPhoneProfile(user.uid, cleanUsername)
            } else {
                pendingPhoneProfileUid = null
                repository.loadUserProfile(user.uid)
                    .addOnCompleteListener { profileResult ->
                        _holdAuthScreenForPhoneSetup.value = false
                        if (profileResult.isSuccessful && profileResult.result.exists()) {
                            showMessage("Welcome back to Lyko!")
                        } else {
                            showMessage("Your existing profile could not be loaded.")
                        }
                    }
            }
        }
    }

    private val _phoneProfilePending = MutableStateFlow(false)
    val phoneProfilePending = _phoneProfilePending.asStateFlow()

    fun completePhoneProfile(username: String) {
        val uid = pendingPhoneProfileUid
        val cleanUsername = username.trim().removePrefix("@")
        if (!_phoneProfilePending.value || uid.isNullOrBlank() || cleanUsername.isBlank()) {
            showMessage("Please enter a username.")
            return
        }
        saveNewPhoneProfile(uid, cleanUsername)
    }

    private fun saveNewPhoneProfile(uid: String, username: String) {
        val cleanUsername = username.trim().removePrefix("@").lowercase()

        if (!cleanUsername.matches(Regex("^[a-z0-9_]{3,20}$"))) {
            _phoneProfilePending.value = true
            showMessage("Username must be 3-20 characters using letters, numbers, or underscores.")
            return
        }

        repository.createUserProfile(uid, cleanUsername)
            .addOnCompleteListener { profileResult ->
                if (profileResult.isSuccessful) {
                    pendingPhoneProfileUid = null
                    _phoneProfilePending.value = false
                    _holdAuthScreenForPhoneSetup.value = false
                    repository.loadUserProfile(uid)
                    showMessage("Your Lyko account has been created!")
                } else {
                    _phoneProfilePending.value = true
                    showMessage(
                        profileResult.exception?.localizedMessage
                            ?: "Profile could not be saved. Please try again."
                    )
                }
            }
    }

    fun toggleLikePost(postId: String) {
        repository.toggleLikePost(postId)
    }

    fun toggleSavePost(postId: String) {
        repository.toggleSavePost(postId)
        showMessage("Post saved to your collection")
    }

    fun toggleFollowUser(userId: String) {
        repository.toggleFollowUser(userId)
    }

    fun addComment(postId: String, text: String) {
        if (text.isBlank()) return
        repository.addComment(postId, text)
    }

    fun getCommentsForPost(postId: String): StateFlow<List<Comment>> {
        return repository.postComments.map { it[postId] ?: emptyList() }
            .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    }

    fun getMessagesForChat(chatId: String): StateFlow<List<Message>> {
        return repository.messages.map { it[chatId] ?: emptyList() }
            .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    }

    fun getLiveComments(streamId: String): StateFlow<List<LiveComment>> {
        return repository.liveComments.map { it[streamId] ?: emptyList() }
            .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    }

    fun toggleLikeReel(reelId: String) {
        repository.toggleLikeReel(reelId)
    }

    fun sendChatMessage(chatId: String, text: String) {
        if (text.isBlank()) return
        repository.sendMessage(chatId, text, MessageType.TEXT)
    }

    fun startVoiceRecording() {
        _isRecordingVoice.value = true
        _voiceRecordingSeconds.value = 0
        viewModelScope.launch {
            while (_isRecordingVoice.value) {
                delay(1000)
                if (_isRecordingVoice.value) {
                    _voiceRecordingSeconds.value += 1
                }
            }
        }
    }

    fun finishVoiceRecording(chatId: String) {
        val duration = _voiceRecordingSeconds.value.coerceAtLeast(1)
        _isRecordingVoice.value = false
        repository.sendMessage(chatId, "Voice note (0:${if (duration < 10) "0$duration" else "$duration"})", MessageType.VOICE, duration)
        _voiceRecordingSeconds.value = 0
    }

    fun cancelVoiceRecording() {
        _isRecordingVoice.value = false
        _voiceRecordingSeconds.value = 0
    }

    fun createGroupChat(title: String, participantIds: List<String>) {
        if (title.isBlank() || participantIds.isEmpty()) {
            showMessage("Please enter a group title and select members")
            return
        }
        repository.createGroupChat(title, participantIds)
        showMessage("Group chat '$title' created!")
        _currentScreen.value = NavigationDestination.MESSAGES
    }

    fun sendLiveComment(streamId: String, text: String) {
        if (text.isBlank()) return
        repository.addLiveComment(streamId, text)
    }

    fun sendLiveTip(streamId: String, amount: String) {
        repository.addLiveComment(streamId, "Sent a $amount super-gift! 💎✨", isDonation = true, amount = amount)
        _heartBurstCount.value += 3
        showMessage("Sent $amount gift to host!")
    }

    fun sendLiveHeart(streamId: String) {
        repository.sendLiveHeart(streamId)
        _heartBurstCount.value += 1
    }

    fun goLive(title: String, category: String) {
        val stream = repository.goLive(title.ifBlank { "Live Studio Session" }, category)
        _selectedLiveStreamId.value = stream.id
        _currentScreen.value = NavigationDestination.LIVE_ROOM
        showMessage("You are now broadcasting live on Lyko!")
    }

    fun createStory(mediaUrl: String, textOverlay: String) {
        repository.createStory(mediaUrl, textOverlay)
        showMessage("Story added!")
        _currentScreen.value = NavigationDestination.FEED
    }

    // Admin studio functions
    fun toggleUserBan(userId: String) {
        repository.toggleUserBan(userId)
        val user = allUsers.value.find { it.id == userId }
        val status = if (user?.isBanned == true) "unbanned" else "banned"
        showMessage("User @${user?.username} has been $status.")
    }

    fun toggleUserVerification(userId: String, status: VerificationStatus) {
        repository.toggleUserVerification(userId, status)
        showMessage("User verification status updated.")
    }

    fun resolveReport(reportId: String, resolution: String) {
        repository.resolveReport(reportId, resolution)
        showMessage("Report status set to $resolution.")
    }

    fun submitReport(reason: String) {
        val target = _reportTarget.value ?: return
        repository.reportContent(
            reporterName = currentUser.value.displayName,
            reportedItemId = target.first,
            itemType = target.second,
            snippet = "User report for ${target.second} ID ${target.first}",
            reason = reason
        )
        _reportTarget.value = null
        showMessage("Report submitted to moderation team. Thank you.")
    }

    fun toggleBlockUser(userId: String) {
        repository.toggleBlockUser(userId)
        val isBlocked = blockedUserIds.value.contains(userId)
        showMessage(if (!isBlocked) "User blocked and restricted" else "User unblocked")
    }

    fun toggleAdCampaign(campaignId: String) {
        repository.toggleAdCampaign(campaignId)
    }

    fun openChatThread(chatId: String) {
        openChat(chatId)
    }

    fun getMessagesForThread(chatId: String): StateFlow<List<Message>> {
        return getMessagesForChat(chatId)
    }

    fun startOrGetDirectChatWith(targetUserId: String): String {
        val existing = chatRooms.value.find { !it.isGroup && it.participants.any { p -> p.id == targetUserId } }
        if (existing != null) return existing.id
        val targetUser = allUsers.value.find { it.id == targetUserId }
        val newId = "chat_" + targetUserId
        val newRoom = ChatRoom(
            id = newId,
            isGroup = false,
            title = targetUser?.displayName ?: "Direct Message",
            avatarUrl = targetUser?.avatarUrl ?: "",
            participants = listOf(currentUser.value, targetUser ?: User(id = targetUserId, username = "creator", displayName = "Creator", avatarUrl = "")),
            unreadCount = 0,
            isEncrypted = true
        )
        // Add to rooms
        return newId
    }

    fun sendMessage(threadId: String, content: String, mediaUrl: String? = null) {
        if (mediaUrl != null) {
            repository.sendMessage(threadId, content, MessageType.IMAGE)
        } else {
            sendChatMessage(threadId, content)
        }
    }

    fun sendVoiceNote(threadId: String, durationSeconds: Int) {
        repository.sendMessage(threadId, "Voice note (0:${if (durationSeconds < 10) "0$durationSeconds" else "$durationSeconds"})", MessageType.VOICE, durationSeconds)
    }

    fun getCommentsForLive(streamId: String): StateFlow<List<LiveComment>> {
        return getLiveComments(streamId)
    }

    fun addCommentToLive(streamId: String, text: String) {
        sendLiveComment(streamId, text)
    }

    fun startLiveStream(title: String, category: String): LiveStream {
        val stream = repository.goLive(title, category)
        _selectedLiveStreamId.value = stream.id
        return stream
    }

    fun setUserVerification(userId: String, status: VerificationStatus) {
        toggleUserVerification(userId, status)
    }

    fun markNotificationRead(notificationId: String) {
        // Mark read
    }

    fun updateProfile(
        displayName: String,
        bio: String,
        website: String,
        avatarUrl: String = "",
        bannerUrl: String = "",
        username: String = currentUser.value.username,
        onResult: (Boolean) -> Unit
    ) {
        repository.updateProfile(
            displayName = displayName,
            bio = bio,
            website = website,
            avatarUrl = avatarUrl,
            bannerUrl = bannerUrl,
            username = username
        ) { success, error ->
            if (success) {
                showMessage("Profile updated successfully!")
            } else {
                showMessage(error ?: "Profile could not be saved.")
            }
            onResult(success)
        }
    }

    fun createPost(
        caption: String,
        mediaUrls: List<String>,
        tags: List<String>,
        location: String,
        type: PostType = PostType.IMAGE,
        isSponsored: Boolean = false,
        sponsorCtaText: String? = null
    ) {
        repository.createPost(caption, mediaUrls, tags, location)
        showMessage("Your post is live on Lyko!")
        _currentScreen.value = NavigationDestination.FEED
    }

    fun resolveReport(reportId: String, action: ModerationAction) {
        val resolution = when (action) {
            ModerationAction.DELETE_POST -> "Resolved - Post Deleted"
            ModerationAction.BAN_USER -> "Resolved - User Banned"
            ModerationAction.DISMISS -> "Dismissed"
            ModerationAction.WARN_USER -> "Resolved - Warning Sent"
        }
        repository.resolveReport(reportId, resolution)
        showMessage("Report status set to $resolution.")
    }

    fun authenticate(email: String, password: String, isSignUp: Boolean, username: String) {
        val cleanEmail = email.trim()
        if (cleanEmail.isBlank() || password.isBlank()) {
            showMessage("Please enter your email and password.")
            return
        }
        if (isSignUp && username.isBlank()) {
            showMessage("Please enter a username.")
            return
        }
        if (isSignUp && password.length < 6) {
            showMessage("Password must be at least 6 characters.")
            return
        }

        val task = if (isSignUp) repository.register(cleanEmail, password)
            else repository.login(cleanEmail, password)

        task.addOnCompleteListener { result ->
            if (!result.isSuccessful) {
                showMessage(result.exception?.localizedMessage ?: "Authentication failed.")
                return@addOnCompleteListener
            }

            if (isSignUp) {
                val user = result.result.user
                if (user == null) {
                    showMessage("Account created, but user profile could not be loaded.")
                    return@addOnCompleteListener
                }

                val profile = UserProfileChangeRequest.Builder()
                    .setDisplayName(username.trim())
                    .build()

                user.updateProfile(profile).addOnCompleteListener profileUpdate@{ profileResult ->
                    if (!profileResult.isSuccessful) {
                        showMessage("Account created, but profile update failed.")
                        return@profileUpdate
                    }

                    repository.createUserProfile(user.uid, username)
                        .addOnCompleteListener firestoreProfile@{ profileDocResult ->
                            if (!profileDocResult.isSuccessful) {
                                showMessage(
                                    profileDocResult.exception?.localizedMessage
                                        ?: "Account created, but Firestore profile could not be saved."
                                )
                                return@firestoreProfile
                            }

                            repository.loadUserProfile(user.uid)

                            user.sendEmailVerification().addOnCompleteListener { emailResult ->
                                if (emailResult.isSuccessful) {
                                    showMessage("Account created. Please check your email to verify it.")
                                } else {
                                    showMessage("Account created, but verification email could not be sent.")
                                }
                            }
                        }
                }
            } else {
                val user = result.result.user
                if (user == null) {
                    showMessage("Login successful, but account details were unavailable.")
                    return@addOnCompleteListener
                }

                repository.loadUserProfile(user.uid)
                    .addOnCompleteListener { profileResult ->
                        if (profileResult.isSuccessful && profileResult.result.exists()) {
                            showMessage("Welcome back to Lyko!")
                        } else {
                            showMessage(
                                profileResult.exception?.localizedMessage
                                    ?: "Your profile could not be loaded from Firestore."
                            )
                        }
                    }
            }
        }
    }

    fun sendPasswordReset(email: String) {
        val cleanEmail = email.trim()
        if (cleanEmail.isBlank()) {
            showMessage("Enter your email address first.")
            return
        }

        repository.sendPasswordResetEmail(cleanEmail).addOnCompleteListener { result ->
            if (result.isSuccessful) {
                showMessage("Password reset link sent. Check your email.")
            } else {
                showMessage(result.exception?.localizedMessage ?: "Could not send reset email.")
            }
        }
    }

    fun logout() {
        repository.logout()
        showMessage("Logged out successfully.")
    }
}
