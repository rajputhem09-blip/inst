package com.example.ui.screens.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.VerificationStatus
import com.example.ui.theme.LykoCyanTertiary
import com.example.ui.theme.LykoVioletPrimary
import com.example.ui.viewmodel.LykoViewModel
import com.example.ui.viewmodel.NavigationDestination

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsPrivacyScreen(
    viewModel: LykoViewModel,
    modifier: Modifier = Modifier
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val allUsers by viewModel.allUsers.collectAsState()

    val isPrivateAccount by viewModel.isPrivateAccount.collectAsState()
    val allowDirectMessagesFromEveryone by viewModel.allowDirectMessagesFromEveryone.collectAsState()
    val filterOffensiveComments by viewModel.filterOffensiveComments.collectAsState()
    val highQualityMediaUploads by viewModel.highQualityMediaUploads.collectAsState()
    val blockedUserIds by viewModel.blockedUserIds.collectAsState()
    var showBlockedAccountsDialog by remember { mutableStateOf(false) }
    var showVerificationRequestDialog by remember { mutableStateOf(false) }
    var selectedSettingsSection by remember { mutableStateOf<String?>(null) }

    val blockedUsers = remember(allUsers, blockedUserIds) {
        allUsers.filter { it.id in blockedUserIds }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Settings & Privacy",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateTo(NavigationDestination.PROFILE) }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Security & Encryption Section
            item {
                SettingsSectionHeader(title = "Security & Encryption")
                ListItem(
                    headlineContent = { Text("End-to-End Encryption (E2EE)") },
                    supportingContent = { Text("End-to-end encryption has not been implemented or verified yet.") },
                    leadingContent = { Icon(Icons.Default.Lock, contentDescription = null, tint = LykoCyanTertiary) },
                    trailingContent = {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = LykoCyanTertiary.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "NOT ENABLED",
                                color = LykoCyanTertiary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            }

            // Privacy Controls
            item {
                SettingsSectionHeader(title = "Privacy & Safety")

                ListItem(
                    headlineContent = { Text("Private Account") },
                    supportingContent = { Text("Your preference is saved on this device; profile visibility enforcement is not connected yet.") },
                    leadingContent = { Icon(Icons.Outlined.Shield, contentDescription = null) },
                    trailingContent = {
                        Switch(
                            checked = isPrivateAccount,
                            onCheckedChange = {
                                viewModel.setPrivateAccount(it)
                                viewModel.showMessage(if (it) "Account switched to Private" else "Account switched to Public")
                            }
                        )
                    }
                )

                ListItem(
                    headlineContent = { Text("Direct Message Requests") },
                    supportingContent = { Text("Save your preference; chat request enforcement is not connected yet.") },
                    leadingContent = { Icon(Icons.Outlined.Message, contentDescription = null) },
                    trailingContent = {
                        Switch(
                            checked = allowDirectMessagesFromEveryone,
                            onCheckedChange = { viewModel.setDirectMessagesFromEveryone(it) }
                        )
                    }
                )

                ListItem(
                    headlineContent = { Text("AI Anti-Spam & Comment Filter") },
                    supportingContent = { Text("Save your preference; automatic comment filtering is not connected yet.") },
                    leadingContent = { Icon(Icons.Outlined.FilterAlt, contentDescription = null) },
                    trailingContent = {
                        Switch(
                            checked = filterOffensiveComments,
                            onCheckedChange = { viewModel.setOffensiveCommentFilter(it) }
                        )
                    }
                )

                ListItem(
                    headlineContent = { Text("Blocked Accounts (${blockedUsers.size})") },
                    supportingContent = { Text("Manage users you have blocked") },
                    leadingContent = { Icon(Icons.Outlined.Block, contentDescription = null) },
                    trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null) },
                    modifier = Modifier.clickable { showBlockedAccountsDialog = true }
                )

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            }

            // Creator & Verification
            item {
                SettingsSectionHeader(title = "Creator & Verification")

                ListItem(
                    headlineContent = { Text("Request Verification Badge") },
                    supportingContent = {
                        Text(
                            when (currentUser.verification) {
                                VerificationStatus.VERIFIED_CREATOR -> "Current status: Verified Creator ✨"
                                VerificationStatus.VERIFIED_OFFICIAL -> "Current status: Official Account 🔵"
                                VerificationStatus.VERIFIED_ADMIN -> "Current status: Platform Administrator 🛡️"
                                VerificationStatus.NONE -> "Apply for creator or official verification badge"
                            }
                        )
                    },
                    leadingContent = { Icon(Icons.Default.Verified, contentDescription = null, tint = LykoVioletPrimary) },
                    trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null) },
                    modifier = Modifier.clickable { showVerificationRequestDialog = true }
                )

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            }

            // Media & App Experience
            item {
                SettingsSectionHeader(title = "Preferences & Data")

                ListItem(
                    headlineContent = { Text("Upload in High Quality") },
                    supportingContent = { Text("Save your preference; upload quality enforcement is not connected yet.") },
                    leadingContent = { Icon(Icons.Outlined.Hd, contentDescription = null) },
                    trailingContent = {
                        Switch(
                            checked = highQualityMediaUploads,
                            onCheckedChange = { viewModel.setHighQualityMediaUploads(it) }
                        )
                    }
                )

                ListItem(
                    headlineContent = { Text("Clear Local Cache") },
                    supportingContent = { Text("Free up storage (currently 14.2 MB)") },
                    leadingContent = { Icon(Icons.Outlined.CleaningServices, contentDescription = null) },
                    modifier = Modifier.clickable { viewModel.showMessage("Cache clearing is not connected yet.") }
                )

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            }


            item {
                ListItem(
                    headlineContent = { Text("Crossposting & Sharing") },
                    supportingContent = { Text("Crossposting controls, resharing permissions, link sharing and saving preferences.") },
                    leadingContent = { Icon(Icons.Outlined.Settings, contentDescription = null) },
                    trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null) },
                    modifier = Modifier.clickable { selectedSettingsSection = "Crossposting & Sharing" }
                )
            }

            item {
                ListItem(
                    headlineContent = { Text("Story, Live & Location") },
                    supportingContent = { Text("Story audience, story replies, live interaction controls and location-sharing preferences.") },
                    leadingContent = { Icon(Icons.Outlined.Settings, contentDescription = null) },
                    trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null) },
                    modifier = Modifier.clickable { selectedSettingsSection = "Story, Live & Location" }
                )
            }

            item {
                ListItem(
                    headlineContent = { Text("Tags, Mentions & Comments") },
                    supportingContent = { Text("Who can tag or mention you, tag approval and comment permissions.") },
                    leadingContent = { Icon(Icons.Outlined.Settings, contentDescription = null) },
                    trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null) },
                    modifier = Modifier.clickable { selectedSettingsSection = "Tags, Mentions & Comments" }
                )
            }

            item {
                ListItem(
                    headlineContent = { Text("Restricted Accounts & Limits") },
                    supportingContent = { Text("Restricted accounts, interaction limits and unwanted-contact controls.") },
                    leadingContent = { Icon(Icons.Outlined.Settings, contentDescription = null) },
                    trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null) },
                    modifier = Modifier.clickable { selectedSettingsSection = "Restricted Accounts & Limits" }
                )
            }

            item {
                ListItem(
                    headlineContent = { Text("Hidden Words") },
                    supportingContent = { Text("Manage hidden words, phrases and message/comment filtering preferences.") },
                    leadingContent = { Icon(Icons.Outlined.Settings, contentDescription = null) },
                    trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null) },
                    modifier = Modifier.clickable { selectedSettingsSection = "Hidden Words" }
                )
            }

            item {
                ListItem(
                    headlineContent = { Text("Follow & Invite Friends") },
                    supportingContent = { Text("Find friends, invite contacts and manage follow-related preferences.") },
                    leadingContent = { Icon(Icons.Outlined.Settings, contentDescription = null) },
                    trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null) },
                    modifier = Modifier.clickable { selectedSettingsSection = "Follow & Invite Friends" }
                )
            }

            item {
                ListItem(
                    headlineContent = { Text("Muted Accounts") },
                    supportingContent = { Text("Review accounts and content you have muted.") },
                    leadingContent = { Icon(Icons.Outlined.Settings, contentDescription = null) },
                    trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null) },
                    modifier = Modifier.clickable { selectedSettingsSection = "Muted Accounts" }
                )
            }

            item {
                ListItem(
                    headlineContent = { Text("Content Preferences") },
                    supportingContent = { Text("Manage suggested content, sensitive-content preferences and topics.") },
                    leadingContent = { Icon(Icons.Outlined.Settings, contentDescription = null) },
                    trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null) },
                    modifier = Modifier.clickable { selectedSettingsSection = "Content Preferences" }
                )
            }

            item {
                ListItem(
                    headlineContent = { Text("Device Permissions & Downloads") },
                    supportingContent = { Text("Review camera, microphone, photos, location permissions and download preferences.") },
                    leadingContent = { Icon(Icons.Outlined.Settings, contentDescription = null) },
                    trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null) },
                    modifier = Modifier.clickable { selectedSettingsSection = "Device Permissions & Downloads" }
                )
            }

            item {
                ListItem(
                    headlineContent = { Text("Accessibility & Language") },
                    supportingContent = { Text("Language, captions, text accessibility and display preferences.") },
                    leadingContent = { Icon(Icons.Outlined.Settings, contentDescription = null) },
                    trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null) },
                    modifier = Modifier.clickable { selectedSettingsSection = "Accessibility & Language" }
                )
            }

            item {
                ListItem(
                    headlineContent = { Text("Data Usage & Media Quality") },
                    supportingContent = { Text("Data saver, autoplay and high-quality media preferences.") },
                    leadingContent = { Icon(Icons.Outlined.Settings, contentDescription = null) },
                    trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null) },
                    modifier = Modifier.clickable { selectedSettingsSection = "Data Usage & Media Quality" }
                )
            }

            item {
                ListItem(
                    headlineContent = { Text("Family Center") },
                    supportingContent = { Text("Family safety information and supervised-account options.") },
                    leadingContent = { Icon(Icons.Outlined.Settings, contentDescription = null) },
                    trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null) },
                    modifier = Modifier.clickable { selectedSettingsSection = "Family Center" }
                )
            }

            item {
                ListItem(
                    headlineContent = { Text("Orders & Fundraisers") },
                    supportingContent = { Text("Order history and fundraiser-related information.") },
                    leadingContent = { Icon(Icons.Outlined.Settings, contentDescription = null) },
                    trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null) },
                    modifier = Modifier.clickable { selectedSettingsSection = "Orders & Fundraisers" }
                )
            }

            item {
                ListItem(
                    headlineContent = { Text("Help & Privacy Center") },
                    supportingContent = { Text("Help topics, support information, privacy guidance and account safety.") },
                    leadingContent = { Icon(Icons.Outlined.Settings, contentDescription = null) },
                    trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null) },
                    modifier = Modifier.clickable { selectedSettingsSection = "Help & Privacy Center" }
                )
            }

            item {
                ListItem(
                    headlineContent = { Text("Profile Status & About") },
                    supportingContent = { Text("Profile status, app information, version and policy details.") },
                    leadingContent = { Icon(Icons.Outlined.Settings, contentDescription = null) },
                    trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null) },
                    modifier = Modifier.clickable { selectedSettingsSection = "Profile Status & About" }
                )
            }

            item {
                ListItem(
                    headlineContent = { Text("Meta Apps") },
                    supportingContent = { Text("Information about connected external apps and account integrations.") },
                    leadingContent = { Icon(Icons.Outlined.Settings, contentDescription = null) },
                    trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null) },
                    modifier = Modifier.clickable { selectedSettingsSection = "Meta Apps" }
                )
            }

            // About & Legal
            item {
                SettingsSectionHeader(title = "About Lyko")
                ListItem(
                    headlineContent = { Text("Lyko Social App") },
                    supportingContent = { Text("Version 2.4.0 (2026 Edition)") },
                    leadingContent = { Icon(Icons.Outlined.Info, contentDescription = null) }
                )

                ListItem(
                    headlineContent = { Text("Log Out", color = MaterialTheme.colorScheme.error) },
                    leadingContent = { Icon(Icons.Default.Logout, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                    modifier = Modifier.clickable { viewModel.logout() }
                )
            }
        }
    }


    // Additional Settings Information Dialog
    selectedSettingsSection?.let { section ->
        val details = when (section) {
            "Crossposting & Sharing" ->
                "Crossposting, resharing, link sharing and saving preferences. External sharing integration is not connected yet."
            "Story, Live & Location" ->
                "Story audience, replies, live controls and location preferences. Location access must be separately granted through Android."
            "Tags, Mentions & Comments" ->
                "Tagging, mentions, tag approval and comment permissions. Server-side enforcement is not connected yet."
            "Restricted Accounts & Limits" ->
                "Restricted accounts and interaction limits. Account restriction enforcement is not connected yet."
            "Hidden Words" ->
                "Hidden words and phrase preferences. Automatic filtering is not connected yet."
            "Follow & Invite Friends" ->
                "Friend discovery and invitation options. Contact access and invitation services are not connected yet."
            "Muted Accounts" ->
                "Muted account management. Mute controls are not connected yet."
            "Content Preferences" ->
                "Suggested content and sensitive-content preferences. Recommendation controls are not connected yet."
            "Device Permissions & Downloads" ->
                "Manage Android permissions in system settings. Downloads and media access need Android integration."
            "Accessibility & Language" ->
                "Language, captions and accessibility preferences. App-wide language and accessibility controls are not connected yet."
            "Data Usage & Media Quality" ->
                "Data saver, autoplay and media quality preferences. Network and playback enforcement are not connected yet."
            "Family Center" ->
                "Family safety information. Supervision and family-link integration are not connected yet."
            "Orders & Fundraisers" ->
                "Order and fundraiser information. These services are not connected yet."
            "Help & Privacy Center" ->
                "Help, support and privacy information. Support request submission is not connected yet."
            "Profile Status & About" ->
                "Profile status and app information. Check the About section for the current app information."
            "Meta Apps" ->
                "External Meta services are not connected to Lyko. Lyko is a separate app."
            else -> "Settings information."
        }

        AlertDialog(
            onDismissRequest = { selectedSettingsSection = null },
            title = { Text(section, fontWeight = FontWeight.Bold) },
            text = { Text(details) },
            confirmButton = {
                TextButton(onClick = { selectedSettingsSection = null }) {
                    Text("Close")
                }
            }
        )
    }

    // Blocked Accounts Dialog
    if (showBlockedAccountsDialog) {
        AlertDialog(
            onDismissRequest = { showBlockedAccountsDialog = false },
            title = { Text("Blocked Accounts", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    if (blockedUsers.isEmpty()) {
                        Text("You haven't blocked any accounts.", fontSize = 13.sp)
                    } else {
                        blockedUsers.forEach { user ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("@${user.username}", fontWeight = FontWeight.Bold)
                                TextButton(onClick = { viewModel.toggleBlockUser(user.id) }) {
                                    Text("Unblock", color = Color(0xFF10B981))
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showBlockedAccountsDialog = false }) {
                    Text("Done")
                }
            }
        )
    }

    // Verification Request Dialog
    if (showVerificationRequestDialog) {
        var linksInput by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showVerificationRequestDialog = false },
            title = { Text("Apply for Creator Verification", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "To get the Lyko Verified Creator badge, share links to your portfolio, music channels, or creative profiles:",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = linksInput,
                        onValueChange = { linksInput = it },
                        placeholder = { Text("https://soundcloud.com/..., https://artstation.com/...") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.showMessage(
                            "Verification applications are not connected yet. No badge has been granted."
                        )
                        showVerificationRequestDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LykoVioletPrimary)
                ) {
                    Text("Submit Application")
                }
            },
            dismissButton = {
                TextButton(onClick = { showVerificationRequestDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun SettingsSectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.Bold,
        color = LykoVioletPrimary,
        modifier = Modifier.padding(start = 16.dp, top = 14.dp, end = 16.dp, bottom = 4.dp)
    )
}
